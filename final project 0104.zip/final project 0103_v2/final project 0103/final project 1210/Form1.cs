﻿using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Media;
using System.Net.Http;
using System.Reflection;
using System.Security.Policy;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using HtmlAgilityPack;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Data.SqlClient;

namespace final_project_1210
{

    public partial class Form1 : Form
    {
        
        //public int ValueToPass_feed { get; set; }
        //從form4傳回來的recieved feed

        public struct data_type
        {
            public string category;
            public int y, m, d;
            public string date;
            public bool cost_incomes;
            public string remarks;
            public double moneys;

            public void UpdateMoneys(double newMoneys)
            {
                moneys = newMoneys;
            }

        }
        Dictionary<bool, string> cost_incomes_int_to_string = new Dictionary<bool, string>(){[true] = "收入", [false] = "支出"};
        List<data_type> datas = new List<data_type>();
        List<string> winningNumbers = new List<string>();
        //Dictionary<string, data_type> datas = new Dictionary<string, data_type>(); //用Dictionary分類data的category
        List<string> winning_number =   new List<string>();
        Dictionary<string, string> btnindex_category = new Dictionary<string, string>();
        public Form1()
        {
            InitializeComponent();   
        }
        int logindays;
        private void search_login(string recordIDToUpdate)//查詢登入天數
        {
            // 替換為您的連線字串
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;" +
                 "AttachDbFilename= |DataDirectory|newuserdata.mdf;" +
                "Integrated Security=True";

            // 替換為實際的資料值
            //string recordIDToUpdate = "user01";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string selectQuery = "SELECT login_days FROM Users WHERE ID = @RecordID";

                using (SqlCommand selectCommand = new SqlCommand(selectQuery, connection))
                {
                    selectCommand.Parameters.AddWithValue("@RecordID", recordIDToUpdate);

                    // 執行 SQL 查詢
                    object result = selectCommand.ExecuteScalar();

                    if (result != null)
                    {
                        logindays = Convert.ToInt32(result);
                    }
                }
            }
        }
        int start_feed;
        private void search_feed(string recordIDToUpdate)//查詢飼料次數
        {
            // 替換為您的連線字串
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;" +
                 "AttachDbFilename= |DataDirectory|newuserdata.mdf;" +
                "Integrated Security=True";

            // 替換為實際的資料值
            //string recordIDToUpdate = "user01";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string selectQuery = "SELECT feed_times FROM Users WHERE ID = @RecordID";

                using (SqlCommand selectCommand = new SqlCommand(selectQuery, connection))
                {
                    selectCommand.Parameters.AddWithValue("@RecordID", recordIDToUpdate);

                    // 執行 SQL 查詢
                    object result = selectCommand.ExecuteScalar();

                    if (result != null)
                    {
                        start_feed = Convert.ToInt32(result);
                    }
                }
            }
        }
        private void update(int newValue, int newValue1, string recordIDToUpdate) //更新登入天數和飼料次數(先飼料，登入)
        {
            // 替換為您的連線字串
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;" +
                 "AttachDbFilename= |DataDirectory|newuserdata.mdf;" +
                "Integrated Security=True";

            // 替換為實際的 SQL 更新語句
            string updateQuery = "UPDATE Users SET login_days = @NewValue2,feed_times = @NewValue1 WHERE ID = @RecordID";

            // 替換為實際的資料值
            //string recordIDToUpdate = "user01";
            //int newValue = 1 ;
            //int newValue1 = 1 ;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand(updateQuery, connection))
                {
                    // 使用參數化查詢以避免 SQL 注入
                    command.Parameters.AddWithValue("@NewValue1", newValue);
                    command.Parameters.AddWithValue("@NewValue2", newValue1);
                    command.Parameters.AddWithValue("@RecordID", recordIDToUpdate);

                    // 執行 SQL 更新語句
                    int rowsAffected = command.ExecuteNonQuery();

                    Console.WriteLine($"{rowsAffected} 行資料已更新");
                }
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            string cn = @"Data Source=(LocalDB)\MSSQLLocalDB;" +
                 "AttachDbFilename= |DataDirectory|newuserdata.mdf;" +
                "Integrated Security=True"; //設為True 指定使用Windows 帳號認證連接資料庫
            SqlConnection db = new SqlConnection(cn);
            db.Open();
            SqlDataAdapter ap = new SqlDataAdapter
                ("SELECT * FROM Users", db);
            DataSet ds = new DataSet();
            ap.Fill(ds, "Users");
            //Form7 t = new Form7();
            //t.Show();
            db.Close();
            web_crawler();
            start_pie();
            start_cal();
            pie_chart(0);
            ColumnAndLine(0);
            button6.Click += Button_Click; button7.Click += Button_Click; button8.Click += Button_Click; button9.Click += Button_Click; button12.Click += Button_Click;
            button13.Click += Button_Click; button14.Click += Button_Click; button15.Click += Button_Click; button16.Click += Button_Click; button17.Click += Button_Click;
            button18.Click += Button_Click; button19.Click += Button_Click; button20.Click += Button_Click; button21.Click += Button_Click; button22.Click += Button_Click;

            btnindex_category.Add("button6", "餐飲食品"); btnindex_category.Add("button8", "服飾美容"); btnindex_category.Add("button7", "居家生活"); btnindex_category.Add("button20", "運輸交通"); btnindex_category.Add("button18", "教育學習");
            btnindex_category.Add("button19", "休閒娛樂"); btnindex_category.Add("button17", "圖書刊物"); btnindex_category.Add("button15", "汽機車"); btnindex_category.Add("button16", "醫療保健"); btnindex_category.Add("button14", "人情交際");
            btnindex_category.Add("button12", "理財投資"); btnindex_category.Add("button13", "其他"); btnindex_category.Add("button21", "薪水"); btnindex_category.Add("button9", "零用錢"); btnindex_category.Add("button22", "投資");

        }


        private async Task web_crawler()
        {
            var url = "https://invoice.etax.nat.gov.tw/";
            var httpclient = new HttpClient();
            var html = await httpclient.GetStringAsync(url);
            var htmldocument = new HtmlAgilityPack.HtmlDocument();
            htmldocument.LoadHtml(html);
            var divs = htmldocument.DocumentNode.Descendants("p").Where(node => node.GetAttributeValue("class", "").Equals("etw-tbiggest"));
            string str;
            int cnt = 0;
            foreach ( var div in divs )
            {
                winning_number.Add(div.Descendants("span").FirstOrDefault().InnerText);
                cnt++;
                if (cnt == 2) break;
            }
            cnt = 0;
            divs = htmldocument.DocumentNode.Descendants("p").Where(node => node.GetAttributeValue("class", "").Equals("etw-tbiggest mb-md-4"));
            foreach (var div in divs)
            {
                str = div.Descendants("span").FirstOrDefault().InnerText;
                str = str + div.Descendants("span").Where(node => node.GetAttributeValue("class", "").Equals("font-weight-bold etw-color-red")).FirstOrDefault().InnerText;
                winning_number.Add(str);
                cnt++;
                if (cnt == 3) break;
            }
            
            foreach (var div in divs)
            {
                winningNumbers.Add(div.Descendants("span").FirstOrDefault()?.InnerText);
            }
        }

        private async void button11_Click(object sender, EventArgs e)
        {
            await web_crawler(); // Call web_crawler method

            if (winningNumbers.Any())
            {
                invoice winningNumbersForm = new invoice(winningNumbers);
                winningNumbersForm.Show(); 
            }
        }

        //建立各個選項的list
        List<double> moneys = new List<double>(); List<string> remarks = new List<string>(); List<string> categorys = new List<string>(); List<string> dates = new List<string>();
        List<bool> cost_incomes = new List<bool>();
        double expenses = 0; //總支出
        double remains = 0; //總收入
        private void add_btn_Click(object sender, EventArgs e)
        {
            string remark = remark_tbx.Text;double money;string category = category_cbx.Text;string date = dateTimePicker1.Text;
            bool check_income=radioButton1.Checked; bool check_cost = radioButton2.Checked;
            //假設全部都有選
            if (money_tbx.Text != string.Empty && string.IsNullOrWhiteSpace(date)==false&&string.IsNullOrWhiteSpace(category)==false && check_income^check_cost) 
            {
                //分類資料
                money = double.Parse(money_tbx.Text);
                data_type data;
                data.y = dateTimePicker1.Value.Year; data.m = dateTimePicker1.Value.Month; data.d = dateTimePicker1.Value.Day;
                data.category = category; data.moneys = money; data.date = date; data.remarks = remark; data.cost_incomes = check_income;
                datas.Add(data);

                remarks.Add(remark);categorys.Add(category);dates.Add(date);
                moneys.Add(money);cost_incomes.Add(check_income);
                MessageBox.Show("成功加入!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
              
                // MessageBox.Show($"{remarks[0]} {categorys[0]} {moneys[0]} {dates[0]}", "提示", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                remark_tbx.Clear(); money_tbx.Clear(); category_cbx.Text = "";

                //更新支出、結餘
                if (check_cost) expenses += money;
                else remains += money;
                label5.Text = "合計支出:" + expenses.ToString();
                label6.Text = "結餘:" + (remains - expenses).ToString();
                update_textbox();
            } 
            else 
            {
                MessageBox.Show("少填選項喔!", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        //限制只能輸入數字
        private void money_tbx_KeyPress(object sender, KeyPressEventArgs e)
        {
            //是否輸入數字
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            //小數點最多只能有一個
            if ((e.KeyChar == '.') && ((sender as System.Windows.Forms.TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
            update_textbox();
        }

        private void dateTimePicker3_ValueChanged(object sender, EventArgs e)
        {
            update_textbox();
        }
        //更新顯示板
        private void update_textbox()
        {
            textBox2.Text = string.Empty;
            //時間範圍上下界
            int left_y = dateTimePicker2.Value.Year; int right_y = dateTimePicker3.Value.Year;
            int left_m = dateTimePicker2.Value.Month; int right_m = dateTimePicker3.Value.Month;
            int left_d = dateTimePicker2.Value.Day; int right_d = dateTimePicker3.Value.Day;
            int left = left_y * 365 + left_m * 31 + left_d;
            int right = right_y * 365 + right_m * 31 + right_d;
            //左界是否小於等於右界
            if (left <= right) {
                foreach(var item in datas)
                {
                    int sum = item.y * 365 + item.m * 31 + item.d;
                    if(left <= sum && sum <= right)
                    {
                        textBox2.Text += cost_incomes_int_to_string[item.cost_incomes] + " " + item.category + " " + item.moneys + " " +item.remarks + Environment.NewLine;
                    }
                }
            }
        }
        //管理項目
        string category_name;
        private void Button_Click(object sender, EventArgs e)
        {
            // 觸發共同的事件
            System.Windows.Forms.Button clickedButton = sender as System.Windows.Forms.Button;
            if (clickedButton != null)
            {
                string name = clickedButton.Name.ToString();
                category_name = btnindex_category[name];
                Form2 frm2 = new Form2(datas,category_name, cost_incomes_int_to_string);
                frm2.Show(); //顯示Form2
            }
        }
        //紀錄飼料有多少個 
        Dictionary<string, int> record_daily_feed_reward = new Dictionary<string, int>();
        int feed = 0;
        private void button10_Click(object sender, EventArgs e)
        {
            //判斷今天是否領過獎勵了
            DateTime TimeNow = DateTime.Now;
            if (record_daily_feed_reward.ContainsKey(TimeNow.ToString("MM/dd/yyyy")))
            {
                MessageBox.Show("已領取過每日登入獎勵!", "獎勵", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            else
            {
                record_daily_feed_reward.Add(TimeNow.ToString("MM/dd/yyyy"), 1);
                record_daily_feed_reward[TimeNow.ToString("MM/dd/yyyy")] = 1;
                search_feed(Form4.search_currentuser());
                feed++;
                MessageBox.Show($"獲得每日登入獎勵!\n飼料+{feed}", "獎勵", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                search_login(Form4.search_currentuser());
                logindays ++;

                //update(feed, logindays);
                update(start_feed+feed, logindays, Form4.search_currentuser());
                //Form6 tryy = new Form6();
                //tryy.Show();
            }
        }
        //鬧鐘
        private int selectedHours;
        private int selectedMinutes;
        private bool isAlarmEnabled;
        private string sound_path;
        private void button23_Click(object sender, EventArgs e)
        {
            using (alarm alarmForm = new alarm())
            {
                DialogResult result = alarmForm.ShowDialog();

                if (result == DialogResult.OK)
                {
                    selectedHours = alarmForm.Hour;
                    selectedMinutes = alarmForm.Minute;
                    isAlarmEnabled = alarmForm.isAlarmEnabled;
                    sound_path = alarmForm.sound_path;
                    timer1.Enabled = true;
                    // Now you have the selected alarm time, do something with it
                    //MessageBox.Show($"鬧鐘時間已設定為：{selectedHours:D2}:{selectedMinutes:D2}");
                }
            }
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            // Check if the current time matches the alarm time
            if (isAlarmEnabled && DateTime.Now.Hour == selectedHours && DateTime.Now.Minute == selectedMinutes)
            {
                timer1.Enabled = false;
                timer2.Enabled = true;
                MessageBox.Show("該記帳了!按下確定即關閉鬧鈴~");
                StopAlarmSound();
            }
        }
        //鬧鈴
        SoundPlayer player1 = new SoundPlayer(); // 建立播放器物件
        private void timer2_Tick(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(sound_path))
            {                        
                player1.SoundLocation = sound_path;           // 指定音效所在路徑檔名
                player1.Load();                                 // 載入音效檔資料
                player1.Play();                                 // 播放音效
            }
            else
            {
                MessageBox.Show("Sound path is empty!");
            }
            timer2.Enabled = false;
        }
        private void StopAlarmSound()
        {
            player1.Stop();
        }
            //改字體
            public void ChangeAllTextFont(Font newFont)
        {
            IterateControls(this, newFont);
        }
        //改顏色
        public void SetTabPageBackgroundColor(Color color)
        {
            tabPage1.BackColor = color; tabPage3.BackColor = color;
            tabPage4.BackColor = color; tabPage5.BackColor = color;
            tabPage6.BackColor = color; tabPage7.BackColor = color;
        }
        private void IterateControls(Control parent, Font newFont)
        {
            foreach (Control control in parent.Controls)
            {
                if (control is System.Windows.Forms.Button || control is Label || control is System.Windows.Forms.TextBox)
                {
                    control.Font = newFont;
                }
                IterateControls(control, newFont);
            }
            if (parent is TabControl tabControl1)
            {
                foreach (TabPage tabPage in tabControl1.TabPages)
                {
                    IterateControls(tabPage, newFont);
                }
            }
        }
        //日期樣式
        public void ChangeDateFormat(string selectedFormat)
        {

            dateTimePicker1.CustomFormat = selectedFormat;
            dateTimePicker2.CustomFormat = selectedFormat; dateTimePicker3.CustomFormat = selectedFormat;
        }
        //幣值
        private double rate;        
        public void ChangeCurrency(double exchangrate)
        {
            rate = exchangrate;       
            UpdateMoneys(); 
        }
        private void UpdateMoneys()
        {
            for (int i = 0; i < moneys.Count; i++)
            {                
                moneys[i] *= rate;
                //MessageBox.Show(moneys[i].ToString());
            }
            update_textbox();
        }
        //動物園
        private void button26_Click(object sender, EventArgs e)
        {
            Form4 form4Instance = Form4.GetInstance(start_feed);
            form4Instance.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            playeraccount accountInstance = playeraccount.GetInstance();
            // 在這裡使用 account 實例//找登入天數(先以記帳的時間為測試)
            accountInstance.ValueToPass_data = datas;
            accountInstance.Show();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }
        //更新今天日期
        int Today_D, Today_M, Today_Y;
        private void update_today_date()
        {
            DateTime today = DateTime.Now;
            string sd = today.ToString("MM/dd/yyyy");
            Today_D = int.Parse(today.ToString("dd"));
            Today_M = int.Parse(today.ToString("MM"));
            Today_Y = int.Parse(today.ToString("yyyy"));
        }
        //取得該日期在今年的週次
        private int GetWeekOfYear(DateTime dt)
        {
            GregorianCalendar gc = new GregorianCalendar();
            return gc.GetWeekOfYear(dt, CalendarWeekRule.FirstDay, DayOfWeek.Monday);
        }
        //本日
        private void button2_Click(object sender, EventArgs e)
        {
            update_today_date();
            textBox2.Text = string.Empty;
            foreach (var item in datas)
            {
                if (Today_D == item.d && Today_M == item.m && Today_Y == item.y)
                {
                    textBox2.Text += cost_incomes_int_to_string[item.cost_incomes] + " " + item.category + " " + item.moneys + " " + item.remarks + Environment.NewLine;
                }
            }
        }
        //本週
        private void button4_Click(object sender, EventArgs e)
        {
            DateTime today = DateTime.Now;
            update_today_date();
            int week = GetWeekOfYear(today);
            textBox2.Text = string.Empty;
            foreach (var item in datas)
            {
                var date1 = new DateTime(item.y, item.m, item.d);
                if (week == GetWeekOfYear(date1) && Today_Y == item.y)
                {
                    textBox2.Text += cost_incomes_int_to_string[item.cost_incomes] + " " + item.category + " " + item.moneys + " " + item.remarks + Environment.NewLine;
                }
            }
        }
        //本月
        private void button3_Click(object sender, EventArgs e)
        {
            update_today_date();
            textBox2.Text = string.Empty;
            foreach (var item in datas)
            {
                if (Today_M == item.m && Today_Y == item.y)
                {
                    textBox2.Text += cost_incomes_int_to_string[item.cost_incomes] + " " + item.category + " " + item.moneys + " " + item.remarks + Environment.NewLine;
                }
            }
        }
        //上個月
        private void button5_Click(object sender, EventArgs e)
        {
            update_today_date();
            textBox2.Text = string.Empty;
            int last_month = Today_M - 1;
            if (last_month == 0) last_month = 12;
            foreach (var item in datas)
            {
                if (last_month == item.m && Today_Y == item.y)
                {
                    textBox2.Text += cost_incomes_int_to_string[item.cost_incomes] + " " + item.category + " " + item.moneys + " " + item.remarks + Environment.NewLine;
                }
            }
        }

        private void button27_Click(object sender, EventArgs e)
        {
            pie_chart(0);
            ColumnAndLine(0);
        }

        private void button28_Click(object sender, EventArgs e)
        {
            pie_chart(1);
            ColumnAndLine(1);
        }

        private void button29_Click(object sender, EventArgs e)
        {
            pie_chart(2);
            ColumnAndLine(2);
        }
        List<string> PieX = new List<string>();
        List<double> PieY = new List<double>();
        List<string> AllX = new List<string>();
        List<double> ColumnY = new List<double>();
        List<double> LineY = new List<double>();
        //圓餅圖
        private void pie_chart(int type)
        {
            //清除前面的資料
            foreach (var series in chart1.Series)
            {
                series.Points.Clear();
            }
            //上傳數據
            if (type == 0)
            {
                pie1();
            }
            else if(type == 1)
            {
                pie2();
            }
            else
            {
                pie3();
            }
            //XY軸
            chart1.Series[0].XValueType = ChartValueType.String;
            chart1.Series[0].YValueType = ChartValueType.Double;
            //綁定XY軸
            chart1.Series[0].Points.DataBindXY(PieX, PieY);
            //滑鼠顯示
            chart1.Series[0].ToolTip = "#VAL";
        }
        private void start_pie()
        {
            //標題
            chart1.Titles.Add("各消費占比");
            chart1.Titles[0].ForeColor = Color.Black;
            chart1.Titles[0].Font = new Font("微软雅黑", 8f, FontStyle.Regular);
            //設計成圓餅圖
            chart1.Series[0].ChartType = SeriesChartType.Pie;
        }
        //圓餅圖本日
        private void pie1()
        {
            DateTime today = DateTime.Now;
            update_today_date();
            foreach (var item in datas)
            {
                if (Today_D == item.d && Today_M == item.m && Today_Y == item.y)
                {
                    if (!PieX.Contains(item.category))
                    {
                        PieX.Add(item.category);
                        AllX.Add(item.category);
                    }
                }
            }
            clear_data();
            for (int i = 0; i < datas.Count(); i++)
            {
                if (Today_D == datas[i].d && Today_M == datas[i].m && Today_Y == datas[i].y)
                {
                    for (int j = 0; j < PieX.Count(); j++)
                    {
                        if (datas[i].category == PieX[j])
                        {
                            PieY[j] += datas[i].moneys;
                            ColumnY[j] += datas[i].moneys;
                            LineY[j] += datas[i].moneys;
                        }
                    }
                }
            }
        }
        //圓餅圖本週
        private void pie2()
        {
            DateTime today = DateTime.Now;
            update_today_date();
            int week = GetWeekOfYear(today);
            foreach (var item in datas)
            {
                var date1 = new DateTime(item.y, item.m, item.d);
                if (week == GetWeekOfYear(date1) && Today_Y == item.y)
                {
                    if (!PieX.Contains(item.category))
                    {
                        AllX.Add(item.category);
                        PieX.Add(item.category);
                    }
                }
            }
            clear_data();
            for (int i = 0; i < datas.Count(); i++)
            {
                var date1 = new DateTime(datas[i].y, datas[i].m, datas[i].d);
                if (week == GetWeekOfYear(date1) && Today_Y == datas[i].y)
                {
                    for (int j = 0; j < PieX.Count(); j++)
                    {
                        if (datas[i].category == PieX[j])
                        {
                            PieY[j] += datas[i].moneys;
                            ColumnY[j] += datas[i].moneys;
                            LineY[j] += datas[i].moneys;
                        }
                    }
                }
            }
        }
        //圓餅圖本月 
        private void pie3()
        {
            DateTime today = DateTime.Now;
            update_today_date();
            foreach (var item in datas)
            {
                if (Today_M == item.m && Today_Y == item.y)
                {
                    if (!PieX.Contains(item.category))
                    {
                        PieX.Add(item.category);
                        AllX.Add(item.category);
                    }
                }
            }
            clear_data();
            for (int i = 0; i < datas.Count(); i++)
            {
                var date1 = new DateTime(datas[i].y, datas[i].m, datas[i].d);
                if (Today_M == datas[i].m && Today_Y == datas[i].y)
                {
                    for (int j = 0; j < PieX.Count(); j++)
                    {
                        if (datas[i].category == PieX[j])
                        {
                            PieY[j] += datas[i].moneys;
                            ColumnY[j] += datas[i].moneys;
                            LineY[j] += datas[i].moneys;
                        }
                    }
                }
            }
        }
        private void clear_data()
        {
            ColumnY.Clear();
            LineY.Clear();
            PieY.Clear();
            for(int i = 0; i < PieX.Count(); i++)
            {

                ColumnY.Add(0);
                LineY.Add(0);
                PieY.Add(0);
            }
        }


        private void button24_Click(object sender, EventArgs e)
        {
            preference preferenceForm = new preference(this);
            preferenceForm.Show();
        }
        //匯出CSV
        private void button25_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog saveFileDialog = new SaveFileDialog())
            {
                saveFileDialog.Filter = "CSV files (*.csv)|*.csv|All files (*.*)|*.*";
                saveFileDialog.Title = "Export CSV";
                saveFileDialog.FileName = "exported_data.csv"; // Default file name

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    CsvExporter.ExportToCsv(dates,categorys,moneys,remarks, saveFileDialog.FileName);
                }
            }
        }
        public class CsvExporter
        {
            public static void ExportToCsv(List<string> dates, List<string> categorys, List<double> moneys, List<string> remarks, string filePath)
            {
                try
                {
                    using (StreamWriter sw = new StreamWriter(filePath, false, new UTF8Encoding(true)))
                    {
                        // Write header row
                        sw.WriteLine("Date,Category,Money,Remark");

                        // Iterate through the lists and write each row to the CSV file
                        for (int i = 0; i < moneys.Count; i++)
                        {
                            sw.WriteLine($"{dates[i]},{categorys[i]},{moneys[i]},{remarks[i]}");
                        }
                    }
                    MessageBox.Show("成功匯出CSV檔!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"匯出失敗: {ex.Message}");
                }
            }
        }
        public static string account, password;
        public static bool login = false;
        //登入登出系統
        private void button30_Click(object sender, EventArgs e)
        {
            if (login)
            {
                DialogResult result = MessageBox.Show("Do you really want to logout?", "Dialog Title", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    account = string.Empty;
                    password = string.Empty;
                    login = false;
                    MessageBox.Show("登出成功!");
                }
            }
            else
            {
                Visible = false;
                UserLogin ul = new UserLogin();
                ul.ShowDialog();
                Visible = true;
            }
        }

        

        //登入
        public static int login_sys(string account,string password)
        {
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;" +
                 "AttachDbFilename= |DataDirectory|newuserdata.mdf;" +
                "Integrated Security=True";
            string recordIDToUpdate = account;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string selectQuery = "SELECT userpassword FROM 帳密 WHERE ID = @RecordID";

                using (SqlCommand selectCommand = new SqlCommand(selectQuery, connection))
                {
                    selectCommand.Parameters.AddWithValue("@RecordID", recordIDToUpdate);

                    // 執行 SQL 查詢
                    object result = selectCommand.ExecuteScalar();

                    if (result != null)
                    {
                        //登入成功
                        if(result.ToString().Trim() == password)
                        {
                            return 0;
                        }
                        //密碼錯誤
                        else
                        {
                            return 1;
                        }
                    }
                    //查無帳號
                    return 2;
                }
            }
        }

       
        //准备数据
        private void ColumnAndLine(int type)
        {
            //清除前面的資料
            foreach (var series in chart2.Series)
            {
                series.Points.Clear();
            }
            if (type == 0)
            {
                pie1();
            }
            else if (type == 1)
            {
                pie2();
            }
            else
            {
                pie3();
            }
            chart2.Series["Column1"].Points.DataBindXY(AllX, ColumnY);
            chart2.Series["Line1"].Points.DataBindXY(AllX, LineY);
            chart2.Series["Column1"].ToolTip = "#VALX:#VAL（个）";
            chart2.Series["Line1"].ToolTip = "#VALX:#VAL（个）";
        }
        private void start_cal()
        {
            //標題
            chart2.Titles.Add("消費趨勢");
            //XY軸標籤
            chart2.ChartAreas[0].AxisX.Title = "月份（月）";
            chart2.ChartAreas[0].AxisY.Title = "数量（个）";
            chart2.Series.Add("Column1");
            chart2.Series.Add("Line1");
            chart2.Series["Column1"].ChartType = SeriesChartType.Column;
            chart2.Series["Line1"].ChartType = SeriesChartType.Line;
            chart2.Series["Column1"].Color = Color.Blue;
            chart2.Series["Line1"].Color = Color.Red;
            chart2.Series["Column1"].BorderWidth = 5;
            chart2.Series["Line1"].BorderWidth = 3;
            chart2.Series["Column1"].XValueType = ChartValueType.String;
            chart2.Series["Column1"].YValueType = ChartValueType.Double;
            chart2.Series["Line1"].XValueType = ChartValueType.String;
            chart2.Series["Line1"].YValueType = ChartValueType.Double;
        }
    }
}
