﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace final_project_1210
{
    public partial class UserLogin : Form
    {
        public UserLogin()
        {
            InitializeComponent();
        }

        private void UserLogin_Load(object sender, EventArgs e)
        {

        }
        //登入
        private void button1_Click(object sender, EventArgs e)
        {
            string account = textBox1.Text;
            string password = textBox2.Text;
            if(check_valid(account) && check_valid(password))
            {
                if (Form1.login_sys(account,password))
                {
                    Form1.account = account;
                    Form1.password = password;
                    MessageBox.Show("登入成功!");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("帳號不存在或密碼錯誤!", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("含有異常字元!", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        //離開
        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do you really want to exit?", "Dialog Title", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }
        string valid_ch = "~`!@#$%^&*()_-+={[}]|\\:;\"'<,>.?/ ";
        private bool check_valid(string s)
        {
            if(s == null || s == string.Empty)
            {
                return false;
            }
            for(int i =  0; i < valid_ch.Count(); i++)
            {
                if (s.Contains(valid_ch[i]))
                {
                    return false;
                }
            }
            return true;
            
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
