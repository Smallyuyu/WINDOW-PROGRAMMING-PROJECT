﻿INSERT INTO Users(Id,login_days,feed_times,collect_animal,current_animal,deer,fox
,cat,羊駝,矮袋鼠,tiger,刺蝟,panda,elephant,松鼠,熊,rabbit)VALUES 
('user01',0, 0,0,'deer',0,0,0,0,0,0,0,0,0,0,0,0)
INSERT INTO Users(Id,login_days,feed_times,collect_animal,current_animal,deer,fox
,cat,羊駝,矮袋鼠,tiger,刺蝟,panda,elephant,松鼠,熊,rabbit)VALUES 
('user02',0, 0,0,'fox',0,0,0,0,0,0,0,0,0,0,0,0)
INSERT INTO Users(Id,login_days,feed_times,collect_animal,current_animal,deer,fox
,cat,羊駝,矮袋鼠,tiger,刺蝟,panda,elephant,松鼠,熊,rabbit)VALUES 
('user03',0, 0,0,'bear',0,0,0,0,0,0,0,0,0,0,0,0)