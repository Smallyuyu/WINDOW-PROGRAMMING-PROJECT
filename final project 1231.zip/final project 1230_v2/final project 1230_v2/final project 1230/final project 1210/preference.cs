﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace final_project_1210
{
    public partial class preference : Form
    {
        public string SelectedDateFormat { get; private set; }
        private Form1 mainForm;

        public preference(Form1 mainForm)
        {
            InitializeComponent();
            this.mainForm = mainForm;

        }

        public preference()
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string selectedColor = color_cbx.SelectedItem.ToString();
            if(selectedColor == "blue")
            {
                Color color = Color.LightBlue;
                mainForm.SetTabPageBackgroundColor(color);
            }
            else if (selectedColor == "red")
            {
                Color color = Color.IndianRed;
                mainForm.SetTabPageBackgroundColor(color);
            }
            else if (selectedColor == "light")
            {
                Color color = Color.White;
                mainForm.SetTabPageBackgroundColor(color);
            }
            else if (selectedColor == "dark")
            {
                Color color = Color.Gray;
                mainForm.SetTabPageBackgroundColor(color);
            }
            else if (selectedColor == "none")
            {
                Color color = Color.Transparent;
                mainForm.SetTabPageBackgroundColor(color);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (fontDialog1.ShowDialog() == DialogResult.OK)
            {   
                font.Font = fontDialog1.Font;
            }
            mainForm.ChangeAllTextFont(fontDialog1.Font);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SelectedDateFormat = comboBox1.Text.ToString();
            mainForm.ChangeDateFormat(SelectedDateFormat);
        }


    }
}
