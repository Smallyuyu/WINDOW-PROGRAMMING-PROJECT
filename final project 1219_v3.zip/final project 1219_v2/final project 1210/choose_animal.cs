﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace final_project_1210
{
    public partial class choose_animal : Form
    {
        public choose_animal()
        {
            InitializeComponent();
        }
        private void choose_animal_Load(object sender, EventArgs e)
        {
            //生成button
            GenerateButtons(12);
        }
        private void GenerateButtons(int buttonCount)
        {
            for (int i = 0; i <= buttonCount; i++)
            {
                Button button = new Button();
                button.Text = "Button " + i;
                button.Name = "button" + i;
                button.Size = new System.Drawing.Size(75, 90);
                button.Location = new System.Drawing.Point(31+80*(i%6),31+134*(i/6));
                button.Click += Button_Click;
                this.Controls.Add(button);
            }
        }

        private void Button_Click(object sender, EventArgs e)
        {
            Button clickedButton = sender as Button;
            if (clickedButton != null)
            {
                string choose = clickedButton.Name;
                DialogResult result = MessageBox.Show("確定要換成這個動物嗎?","提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                if (result == DialogResult.OK) { }//換動物角色
               
            }
        }
    }
}
