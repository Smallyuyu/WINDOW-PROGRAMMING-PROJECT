﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace final_project_1210
{
    public partial class CreateAccount : Form
    {
        public CreateAccount()
        {
            InitializeComponent();
        }
        //離開
        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do you really want to exit?", "Dialog Title", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }
        //註冊
        private void button1_Click(object sender, EventArgs e)
        {
            string account = textBox1.Text;
            string password = textBox2.Text;
            string password2 = textBox3.Text;
            if (UserLogin.check_valid(account) && UserLogin.check_valid(password))
            {
                if(password != password2)
                {
                    MessageBox.Show("重複密碼錯誤!", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                if (Form1.login_sys(account, password) == 2)
                {
                    Form1.account = account;
                    Form1.password = password;
                    create_account(account,password);
                    MessageBox.Show("帳號註冊成功!");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("帳號已存在!", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("含有異常字元!", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        private void create_account(string account,string password)
        {
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;" +
     "AttachDbFilename= |DataDirectory|newuserdata.mdf;" +
    "Integrated Security=True";
            string insertQuery = "INSERT INTO 帳密(Id,userpassword)VALUES \r\n(@RecordID,@NewValue)";
            //open database
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                //insert data
                using (SqlCommand command = new SqlCommand(insertQuery, connection))
                {
                    command.Parameters.AddWithValue("@NewValue", password);
                    command.Parameters.AddWithValue("@RecordID", account);

                    int rowsAffected = command.ExecuteNonQuery();

                }
            }
        }
    }
}
