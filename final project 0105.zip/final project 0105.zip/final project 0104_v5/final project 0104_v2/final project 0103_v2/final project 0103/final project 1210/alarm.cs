﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace final_project_1210
{
    public partial class alarm : Form
    {
        public int Hour { get; private set; }
        public int Minute { get; private set; }
        public bool isAlarmEnabled { get; private set; }
        public string sound_path { get; private set; }
        public alarm()
        {
            InitializeComponent();
            label5.Text = "";
            isAlarmEnabled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Hour = (int)numericUpDown1.Value;
            Minute = (int)numericUpDown2.Value;        
            DialogResult = DialogResult.OK;
            Close();
            MessageBox.Show($"鬧鐘時間已設定為：{Hour:D2}:{Minute:D2}");
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            isAlarmEnabled = checkBox1.Checked;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Title = "Open Sound File";
                openFileDialog.Filter = "Sound Files|*.wav";

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    label5.Text = openFileDialog.FileName;
                    sound_path = openFileDialog.FileName;
                }
            }
        }
       
    }
}
