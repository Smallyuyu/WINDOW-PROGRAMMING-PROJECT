﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static final_project_1210.Form1;

namespace final_project_1210
{
    
    public partial class playeraccount : Form
    {
        
        public int ValueToPass { get; set; }
        //從form1傳回來的datas
        public List<data_type> ValueToPass_data { get; set; }
        //從form5垂回來的動物選擇
        public int ValueToPass_picindex { get; set; }
        //public string ValueToPass_useraccount { get; set; }


        private playeraccount()
        {
            InitializeComponent();
            animalindex_category.Add("deer", 0); animalindex_category.Add("fox", 1); animalindex_category.Add("cat", 2); animalindex_category.Add("羊駝", 3); animalindex_category.Add("矮袋鼠", 4);
            animalindex_category.Add("tiger", 5); animalindex_category.Add("刺蝟", 6); animalindex_category.Add("panda", 7); animalindex_category.Add("elephant", 8); animalindex_category.Add("松鼠", 9);
            animalindex_category.Add("熊", 10); animalindex_category.Add("rabbit", 11);
        }

        //button背景顏色
        List<Color>bg = new List<Color>() { Color.Khaki,Color.DarkKhaki, Color.SteelBlue,Color.DarkOrchid,Color.Teal,Color.OliveDrab,Color.Pink,Color.SkyBlue,Color.MediumAquamarine,Color.YellowGreen,Color.CornflowerBlue,Color.LightSteelBlue };
        Dictionary<string, int> animalindex_category = new Dictionary<string, int>();
        private static playeraccount instance;
        // 靜態方法來取得 Form1 實例
        public static playeraccount GetInstance()
        {
            if (instance == null || instance.IsDisposed)
            {
                instance = new playeraccount();
            }
            return instance;
        }
        string animalresult;
        private void search_currentanimal(string recordIDToUpdate)//查詢目前養的動物
        {
            // 替換為您的連線字串
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;" +
                 "AttachDbFilename= |DataDirectory|newuserdata.mdf;" +
                "Integrated Security=True";

            // 替換為實際的資料值
            //string recordIDToUpdate = "user01";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string selectQuery = "SELECT current_animal FROM Users WHERE ID = @RecordID";

                using (SqlCommand selectCommand = new SqlCommand(selectQuery, connection))
                {
                    selectCommand.Parameters.AddWithValue("@RecordID", recordIDToUpdate);

                    // 執行 SQL 查詢
                    object result = selectCommand.ExecuteScalar();

                    if (result != null)
                    {

                        animalresult = result.ToString().Trim();
                    }
                }
            }
        }
        int kinds_animal;
        private void search_collection_accurate(string name, string recordIDToUpdate)//更新明確動物種類
        {
            // 替換為您的連線字串
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;" +
                 "AttachDbFilename= |DataDirectory|newuserdata.mdf;" +
                "Integrated Security=True";
           
            // 替換為實際的資料值
            //string recordIDToUpdate = "user01";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string selectQuery = $"SELECT {name} FROM Users WHERE ID = @RecordID";

                using (SqlCommand selectCommand = new SqlCommand(selectQuery, connection))
                {
                    selectCommand.Parameters.AddWithValue("@RecordID", recordIDToUpdate);

                    // 執行 SQL 查詢
                    object result = selectCommand.ExecuteScalar();

                    if (result != null)
                    {

                        kinds_animal = Convert.ToInt32(result);
                    }
                }

            }
        }
        int logindays;
        private void search_login(string recordIDToUpdate)//查詢登入天數
        {
            // 替換為您的連線字串
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;" +
                 "AttachDbFilename= |DataDirectory|newuserdata.mdf;" +
                "Integrated Security=True";

            // 替換為實際的資料值
            // string recordIDToUpdate = search_currentuser();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string selectQuery = "SELECT login_days FROM Users WHERE ID = @RecordID";

                using (SqlCommand selectCommand = new SqlCommand(selectQuery, connection))
                {
                    selectCommand.Parameters.AddWithValue("@RecordID", recordIDToUpdate);

                    // 執行 SQL 查詢
                    object result = selectCommand.ExecuteScalar();

                    if (result != null)
                    {
                        logindays = Convert.ToInt32(result);
                    }
                }
            }
        }

        int collect_animals;
        private void search_collection(string recordIDToUpdate)//查詢動物蒐集個數
        {
            // 替換為您的連線字串
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;" +
                 "AttachDbFilename= |DataDirectory|newuserdata.mdf;" +
                "Integrated Security=True";

            // 替換為實際的資料值
            // string recordIDToUpdate = search_currentuser();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string selectQuery = "SELECT collect_animal FROM Users WHERE ID = @RecordID";

                using (SqlCommand selectCommand = new SqlCommand(selectQuery, connection))
                {
                    selectCommand.Parameters.AddWithValue("@RecordID", recordIDToUpdate);

                    // 執行 SQL 查詢
                    object result = selectCommand.ExecuteScalar();

                    if (result != null)
                    {
                        collect_animals = Convert.ToInt32(result);
                    }
                }
            }
        }

        DataSet ds; SqlDataAdapter daEmp;
        string player;
        List<string> all_date= new List<string>();
        private void account_Load_1(object sender, EventArgs e)
        {
            if (Form1.login == false)
            {
                //預設使用者為user01
                player = "user01";

            }
            else { player = Form4.search_currentuser(); }
            string cn = @"Data Source=(LocalDB)\MSSQLLocalDB;" +
                     "AttachDbFilename= |DataDirectory|newuserdata.mdf;" +
                        "Integrated Security=True";
            ds = new DataSet();
            daEmp = new SqlDataAdapter("SELECT * FROM Users", cn);
            daEmp.Fill(ds, "Users");
            search_collection(player);
            label2.Text =collect_animals.ToString();
                //DataBindings.Add("Text", ds, "Users.collect_animal");
          

            GenerateButtons(12);

            //label2.Text = $"目前已累積:       {ValueToPass}    隻動物";
            //等級設定:如果有0-1隻 Lv1 、3 隻 Lv2 以此類推
            //label3.Text = $"Lv:       {(ValueToPass-1)/2+1}";
            label3.Visible = false;
           
            //登入天數
            foreach (var item in ValueToPass_data)
            {
                if (all_date.Contains(item.date) == false) 
                { 
                    all_date.Add(item.date);
                }    
            }
            search_login(player);
            label6.Text =logindays.ToString();
                //DataBindings.Add("Text", ds, "Users.login_days");
            search_currentanimal(player);
            // button1.ImageIndex = ValueToPass_picindex;
            button1.ImageIndex = animalindex_category[animalresult];
            button1.BackColor = bg[button1.ImageIndex];
            // button1.BackColor = bg[ValueToPass_picindex];

            //換下排按鈕顏色(有蒐集到的bg會從灰色到有顏色)
            foreach (KeyValuePair<string,int> pair in animalindex_category) 
            {
                search_collection_accurate(pair.Key, player);
                if (kinds_animal != 0) 
                {
                    int imageindex = animalindex_category[pair.Key];
                    //換下排按鈕顏色(有蒐集到的bg會從灰色到有顏色)
                    for (int i = 0; i <= buttonList.Count; i++)
                    {
                        if (i == imageindex)
                        {
                            buttonList[i].BackColor = bg[imageindex];
                        }
                    }   
                }
            }
        }
        List<Button> buttonList = new List<Button>();
        private void GenerateButtons(int buttonCount)
        {
            for (int i = 0; i <= buttonCount - 1; i++)
            {
                int new_i = i + 2;
                Button button = new Button();
                button.Text = "Button " + new_i;
                button.Name = "button" + new_i;
                button.Size = new System.Drawing.Size(48, 52);
                button.ImageList = imageList1;
                button.ImageIndex = i;
                button.Text = ""; button.BackColor = Color.Gray;
                button.Location = new System.Drawing.Point(1 + 48 * (i % 5), 275 + 52 * (i / 5));
                buttonList.Add(button);
                this.Controls.Add(button);
            }
        }
        private void button2_MouseEnter(object sender, EventArgs e)
        {
            label10.Visible = true;
            label10.Parent = this;
            label10.BackColor = Color.PaleGoldenrod;
            this.label10.Visible = true;
            this.label10.Location = new Point(50, 30);
            this.label10.Text = "遊戲簡介:\n每天登入會給飼料\n每次餵食一次\n期限為一個月\n達到28次即可換得一隻動物\n當一個月結束或是飼養成功\n登入天數和餵食次數會重新計算";
        }

        private void button2_MouseLeave(object sender, EventArgs e)
        {
            this.label10.Visible = false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            search_collection(player);
            label2.Text = collect_animals.ToString();
            search_login(player);
            label6.Text = logindays.ToString();

        }
    }
}
