﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace final_project_1210
{
    //從form4傳回來的值
   
    public partial class Form5 : Form 
    {

        
        //public int ValueToPass_feed { get; set; }
        //button背景顏色
        List<Color> bg = new List<Color>() { Color.Khaki, Color.DarkKhaki, Color.SteelBlue, Color.DarkOrchid, Color.Teal, Color.OliveDrab, Color.Pink, Color.SkyBlue, Color.MediumAquamarine, Color.YellowGreen, Color.CornflowerBlue, Color.LightSteelBlue };
        Dictionary<string, string> btnindex_category = new Dictionary<string, string>();
        Dictionary<int, string> animalindex_category = new Dictionary<int, string>();
        public Form5()
        {
            InitializeComponent();
         
        }
        private static Form5 instance;
        // 靜態方法來取得 Form4 實例
        public static Form5 GetInstance()
        {
            if (instance == null || instance.IsDisposed)
            {
                instance = new Form5();
            }
            return instance;
        }

        private void Form5_Load(object sender, EventArgs e)
        {
           
            GenerateButtons(11);
            animalindex_category.Add(0, "deer"); animalindex_category.Add(1, "fox"); animalindex_category.Add(2, "cat"); animalindex_category.Add(3, "羊駝"); animalindex_category.Add(4, "矮袋鼠");
            animalindex_category.Add(5, "tiger"); animalindex_category.Add(6, "刺蝟"); animalindex_category.Add(7, "panda"); animalindex_category.Add(8, "elephant"); animalindex_category.Add(9, "松鼠");
            animalindex_category.Add(10, "熊"); animalindex_category.Add(11, "rabbit");
            btnindex_category.Add("button0", "button2"); btnindex_category.Add("button1", "button3"); btnindex_category.Add("button2", "button4"); btnindex_category.Add("button3", "button5"); btnindex_category.Add("button4", "button6");
            btnindex_category.Add("button5", "button7"); btnindex_category.Add("button6", "button8"); btnindex_category.Add("button7", "button9"); btnindex_category.Add("button8", "button10"); btnindex_category.Add("button9", "button11");
            btnindex_category.Add("button10", "button12"); btnindex_category.Add("button11", "button13");
        }
        private void GenerateButtons(int buttonCount)
        {
            for (int i = 0; i <= buttonCount; i++)
            {
                Button button = new Button();
                button.Text = "Button " + i;
                button.Name = "button" + i;
                button.Size = new System.Drawing.Size(75, 90);
                button.ImageList = imageList1;
                button.ImageIndex = i;
                button.Text = ""; button.BackColor = bg[i];
                button.Location = new System.Drawing.Point(31 + 80 * (i % 6), 31 + 134 * (i / 6));
                button.Click += Button_Click;
                button.MouseHover += Button_MouseHover;
                this.Controls.Add(button);
            }
        }
        int feed = 0;int animal_index;
        string animal_name_to_account; //int animal_index;
        // Create an array of image paths or Image objects
        private Image[] images = { Properties.Resources.deer1, Properties.Resources.fox1, Properties.Resources.cat1, Properties.Resources.羊駝, Properties.Resources.矮袋鼠, Properties.Resources.tiger, Properties.Resources.刺蝟1, Properties.Resources.panda1, Properties.Resources.elephant, Properties.Resources.elephant, Properties.Resources.松鼠1, Properties.Resources.熊2, Properties.Resources.圖片12 };
        List<int> animal_want = new List<int>();
        private void update_animal_current(string newValue1, string recordIDToUpdate)//更新目前animal
        {
            // 替換為您的連線字串
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;" +
                 "AttachDbFilename= |DataDirectory|newuserdata.mdf;" +
                "Integrated Security=True";

            // 替換為實際的 SQL 更新語句
            string updateQuery = "UPDATE Users SET current_animal = @NewValue1 WHERE ID = @RecordID";

            // 替換為實際的資料值
            //string recordIDToUpdate = "user01";
            //int newValue = 1;
            // int newValue1 = 1;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand(updateQuery, connection))
                {
                    // 使用參數化查詢以避免 SQL 注入

                    command.Parameters.AddWithValue("@NewValue1", newValue1);
                    command.Parameters.AddWithValue("@RecordID", recordIDToUpdate);

                    // 執行 SQL 更新語句
                    int rowsAffected = command.ExecuteNonQuery();

                    Console.WriteLine($"{rowsAffected} 行資料已更新");
                }

            }
        }
        //選擇動物
        private void Button_Click(object sender, EventArgs e)
        {
            Button clickedButton = sender as Button;
            if (clickedButton != null)
            {
                //改變picturebox的動物圖//重置0

                animal_index = clickedButton.ImageIndex;//換照片//form4 account
                //更新動物圖片//資料庫
                update_animal_current(animalindex_category[animal_index],Form4.search_currentuser());
                Form6 tryy = new Form6();
                tryy.Show();
                animal_want.Add(animal_index);
                string animal_name = clickedButton.Name;
                animal_name_to_account = btnindex_category[animal_name];//換按鈕顏色//account
                // 在這裡使用 account 實例
                playeraccount accountInstance = playeraccount.GetInstance();
                accountInstance.ValueToPass_picindex = animal_index;
                Form4 form4Instance = Form4.GetInstance(feed);
                form4Instance.ValueToPass_picindex = animal_index;
                form4Instance.ValueToPass_animal_lastindex = animal_want;
                form4Instance.ValueToPass_animal_visible = true;

            }
        }
        private void Button_MouseHover(object sender, EventArgs e)
        {
            Button hoveredButton = sender as Button;
            if (hoveredButton != null)
            {
                label1.Parent = this;
                this.label1.Visible = true;
                this.label1.Location = hoveredButton.Location;
                this.label1.Text = "想要養這隻動物嗎~\n按下Button即可換動物!!";
            }
        }
    }
}
