﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace final_project_1210
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            GenerateButtons(12);
        }
        private void GenerateButtons(int buttonCount)
        {
            for (int i = 0; i <= buttonCount; i++)
            {
                Button button = new Button();
                button.Text = "Button " + i;
                button.Name = "button" + i;
                button.Size = new System.Drawing.Size(75, 90);
                button.ImageList = imageList1;
                button.ImageIndex = i;
                button.Text = "";button.BackColor = Color.AliceBlue;
                
                button.Location = new System.Drawing.Point(31 + 80 * (i % 6), 31 + 134 * (i / 6));
                button.Click += Button_Click;
                this.Controls.Add(button);
            }
        }

        private void Button_Click(object sender, EventArgs e)
        {
            Button clickedButton = sender as Button;
            if (clickedButton != null)
            {

            }
        }
    }
}
