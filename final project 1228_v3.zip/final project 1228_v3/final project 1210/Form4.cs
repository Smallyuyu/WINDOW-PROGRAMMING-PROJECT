﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Tab;

namespace final_project_1210
{
 
    public partial class Form4 : Form
    {
        

        //從form5傳回來的值
        public int ValueToPass_picindex { get; set; }
        
        
        public List<int> ValueToPass_animal_lastindex { get; set; }
        public int recievefeed = 0; int count1 = 0;
        //private int form4State;

        // 靜態方法來取得 Form1 實例

        private Form4(int feed)
        {
            InitializeComponent();
            recievefeed = feed;
        }
        private static Form4 instance;
        // 靜態方法來取得 Form4 實例
        public static Form4 GetInstance(int feed)
        {
            if (instance == null || instance.IsDisposed)
            {
                instance = new Form4(feed);
            }
            return instance;
        }
        
        
        System.Media.SoundPlayer sp = new SoundPlayer();
        private void Form4_Load(object sender, EventArgs e)
        {
            bg.BackColor = Color.Transparent;
            groupBox1.Parent = bg;
            label4.Parent = bg;label3.Parent = bg;
            animal.Parent = bg;
            label1.Text = "我的飼料:" + recievefeed.ToString();
            label2.BackColor = Color.Transparent;
            progressBar1.Minimum = 0;
            progressBar1.Maximum = 20;
            progressBar1.Step = 1;
            
           // sp.SoundLocation = @"C:\Users\user\source\repos\WINDOW-PROGRAMMING-PROJECT\final project 1219_v2\final project 1219_v2\y5hzl-f6ldt.wav";
           // sp.PlayLooping();
        }
        private void Form4_FormClosing(object sender, EventArgs e) { } //sp.Stop(); }
        int Today_D, Today_M, Today_Y;int animal_sucess = 0;
       
        private void button1_Click(object sender, EventArgs e)
        {
            DateTime today = DateTime.Now;
            Today_D = int.Parse(today.ToString("dd"));
            Today_M = int.Parse(today.ToString("MM"));
            //判斷是否有動物
            if (ValueToPass_picindex>=0)
            {
                animal.Visible = true;
                if (recievefeed == 0)
                {
                    MessageBox.Show("沒有飼料了喔!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    recievefeed--;
                    label1.Text = "我的飼料:" + recievefeed.ToString();
                    count1++;
                    progressBar1.Value = count1;
                    if (progressBar1.Value ==1)//判斷動物是否養成成功
                    {
                        if (Today_D <= 30 || Today_D <= 31)
                        {
                            animal_sucess += 1;
                            account accountInstance = account.GetInstance();
                            // 在這裡使用 account 實例
                            accountInstance.ValueToPass = animal_sucess;
                            // 在這裡使用 form5 實例//讓form5接收值
                            //Form5 form5Instance = Form5.GetInstance();
                            //form5Instance.ValueToPass_feed = recievefeed;
                            MessageBox.Show("養成成功!\n快去動物圖鑑再選擇一隻來養吧~", "成功蒐集1隻", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            //動物消失
                            //animal.Visible = false;
                            recievefeed = 0;
                            // 在這裡使用 form1 實例//讓form1接收值
                            //Form1 form1Instance = Form1.GetInstance();
                            //form1Instance.ValueToPass_feed = recievefeed;

                        }
                    }
                    else if (progressBar1.Value != 1 && Today_D == 30 || Today_D == 31) { MessageBox.Show("養成失敗!\n再接再厲!快去動物圖鑑再重新養一隻吧~", "失敗", MessageBoxButtons.OK, MessageBoxIcon.Error); }
                }
            }
            else { MessageBox.Show("目前沒有養動物喔!\n", "提示", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); }
        }
        
        int move1, move2;
        // Create an array of image paths or Image objects
        private Image[] images = { Properties.Resources.deer1, Properties.Resources.fox1, Properties.Resources.cat1, Properties.Resources.羊駝, Properties.Resources.矮袋鼠, Properties.Resources.tiger, Properties.Resources.刺蝟1, Properties.Resources.panda1, Properties.Resources.elephant, Properties.Resources.松鼠1, Properties.Resources.熊2, Properties.Resources.圖片12 };

        private void button2_MouseMove(object sender, MouseEventArgs e)
        {
            this.label4.Visible = true;
            this.label4.Location = new Point(80, 123);
            this.label4.Text ="動物圖鑑 or 選擇動物";
           
        }

        private void button2_MouseLeave(object sender, EventArgs e)
        {
            this.label4.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form form = new Form5();//換動物養
            form.Show();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Random rd1 = new Random();
            move1=rd1.Next(-100, 100);
            Random rd2 = new Random();
            move2=rd2.Next(-15, 15);
           // Random random = new Random();
            //int randomIndex = random.Next(images.Length);
            if (animal.Location.X <= 615 && animal.Location.X >= -3 && animal.Location.Y >= 102 && animal.Location.Y <= 269)
            {
                animal.Left = move1 + animal.Location.X;
                animal.Top = move2 + animal.Location.Y;
                animal.Image = images[ValueToPass_picindex];
            }
            else 
            { 
                animal.Image = images[ValueToPass_picindex]; 
                animal.Left = 302;
                animal.Top = 225;
            }
        }
        
    }
}
