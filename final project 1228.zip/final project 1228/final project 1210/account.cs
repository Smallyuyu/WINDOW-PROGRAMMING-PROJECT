﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static final_project_1210.Form1;

namespace final_project_1210
{
    
    public partial class account : Form
    {
        
        public int ValueToPass { get; set; }
        //從form1傳回來的datas
        public List<data_type> ValueToPass_data { get; set; }
        //從form5垂回來的動物選擇
        public int ValueToPass_picindex { get; set; }
       
   
        private account()
        {
            InitializeComponent();    
        }

        //button背景顏色
        List<Color>bg = new List<Color>() { Color.Khaki,Color.DarkKhaki, Color.SteelBlue,Color.DarkOrchid,Color.Teal,Color.OliveDrab,Color.Pink,Color.SkyBlue,Color.MediumAquamarine,Color.YellowGreen,Color.CornflowerBlue,Color.LightSteelBlue };
     
        private static account instance;
        // 靜態方法來取得 Form1 實例
        public static account GetInstance()
        {
            if (instance == null || instance.IsDisposed)
            {
                instance = new account();
            }
            return instance;
        }
        

        List<string> all_date= new List<string>(); 
        private void account_Load_1(object sender, EventArgs e)
        {
            GenerateButtons(12);
            label2.Text = $"目前已累積:       {ValueToPass}    隻動物";
            //等級設定:如果有0-1隻 Lv1 、3 隻 Lv2 以此類推
            label3.Text = $"Lv:       {(ValueToPass-1)/2+1}";
            //登入天數
            foreach (var item in ValueToPass_data)
            {
                if (all_date.Contains(item.date) == false) 
                { 
                    all_date.Add(item.date);
                }    
            }
            label6.Text = $"累積登入多少天:       {all_date.Count}";
            button1.ImageIndex = ValueToPass_picindex;
            button1.BackColor = bg[ValueToPass_picindex];
            //換下排按鈕顏色(有蒐集到的bg會從灰色到有顏色)
            for (int i = 0; i <= buttonList.Count; i++) 
            {
                if (i == ValueToPass_picindex )
                {
                    buttonList[i].BackColor = bg[ValueToPass_picindex];
                }
            }
        }
        List<Button> buttonList = new List<Button>();
        private void GenerateButtons(int buttonCount)
        {
            for (int i = 0; i <= buttonCount-1; i++)
            {
                int new_i = i+2;
                Button button = new Button();
                button.Text = "Button " + new_i;
                button.Name = "button" + new_i;
                button.Size = new System.Drawing.Size(48, 52);
                button.ImageList = imageList1;
                button.ImageIndex = i;
                button.Text = ""; button.BackColor = Color.Gray;
                button.Location = new System.Drawing.Point(1 + 48 * (i % 5), 275 + 52 * (i / 5));
                buttonList.Add(button);
                this.Controls.Add(button);
            }
        }
        


    }
}
