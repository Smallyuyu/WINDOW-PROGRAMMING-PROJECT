﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace final_project_1210
{
    public partial class preference : Form
    { 
        private Form1 mainForm;

        public preference(Form1 mainForm)
        {
            InitializeComponent();
            this.mainForm = mainForm;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string selectedColor = color_cbx.SelectedItem.ToString();
            if(selectedColor == "blue")
            {
                // Convert the color name to a Color object
                Color color = Color.LightBlue;

                // Set the background color in the MainForm
                mainForm.SetTabPageBackgroundColor(color);
            }
            else if (selectedColor == "red")
            {
                // Convert the color name to a Color object
                Color color = Color.DarkRed;

                // Set the background color in the MainForm
                mainForm.SetTabPageBackgroundColor(color);
            }
            else if (selectedColor == "gray")
            {
                // Convert the color name to a Color object
                Color color = Color.Gray;

                // Set the background color in the MainForm
                mainForm.SetTabPageBackgroundColor(color);
            }
            else if (selectedColor == "light")
            {
                // Convert the color name to a Color object
                Color color = Color.White;

                // Set the background color in the MainForm
                mainForm.SetTabPageBackgroundColor(color);
            }
            else if (selectedColor == "dark")
            {
                // Convert the color name to a Color object
                Color color = Color.Black;

                // Set the background color in the MainForm
                mainForm.SetTabPageBackgroundColor(color);
            }
            else if (selectedColor == "none")
            {
                // Convert the color name to a Color object
                Color color = Color.Transparent;

                // Set the background color in the MainForm
                mainForm.SetTabPageBackgroundColor(color);
            }
        }
    }
}
