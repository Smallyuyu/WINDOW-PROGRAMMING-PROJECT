﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Tab;

namespace final_project_1210
{
 
    public partial class Form4 : Form
    {
        

        //從form5傳回來的值
        public int ValueToPass_picindex { get; set; }
        
        
        public List<int> ValueToPass_animal_lastindex { get; set; }
        public int recievefeed = 0; int count1 = 0;
        //private int form4State;

        // 靜態方法來取得 Form1 實例
        Dictionary<string, int> animalindex_category = new Dictionary<string, int>();
        private Form4(int feed)
        {
            InitializeComponent();
            recievefeed = feed;//之後再檢查
            animalindex_category.Add("deer", 0); animalindex_category.Add("fox", 1); animalindex_category.Add("cat", 2); animalindex_category.Add("羊駝", 3); animalindex_category.Add("矮袋鼠", 4);
            animalindex_category.Add("tiger", 5); animalindex_category.Add("刺蝟", 6); animalindex_category.Add("panda", 7); animalindex_category.Add("elephant", 8); animalindex_category.Add("松鼠", 9);
            animalindex_category.Add("熊", 10); animalindex_category.Add("rabbit", 11);
        }
        private static Form4 instance;
        // 靜態方法來取得 Form4 實例
        public static Form4 GetInstance(int feed)
        {
            if (instance == null || instance.IsDisposed)
            {
                instance = new Form4(feed);
            }
            return instance;
        }
        //從資料庫抓取資料
        string animalresult;
        private void search_currentanimal()//查詢目前養的動物
        {
            // 替換為您的連線字串
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;" +
                 "AttachDbFilename= |DataDirectory|newuserdata.mdf;" +
                "Integrated Security=True";

            // 替換為實際的資料值
            string recordIDToUpdate = "user01";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string selectQuery = "SELECT current_animal FROM Users WHERE ID = @RecordID";

                using (SqlCommand selectCommand = new SqlCommand(selectQuery, connection))
                {
                    selectCommand.Parameters.AddWithValue("@RecordID", recordIDToUpdate);

                    // 執行 SQL 查詢
                    object result = selectCommand.ExecuteScalar();

                    if (result != null)
                    {
                        animalresult = result.ToString().Trim();
                    }
                }
            }
        }
        int logindays;
        private void search_login()//查詢登入天數
        {
            // 替換為您的連線字串
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;" +
                 "AttachDbFilename= |DataDirectory|newuserdata.mdf;" +
                "Integrated Security=True";

            // 替換為實際的資料值
            string recordIDToUpdate = "user01";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string selectQuery = "SELECT login_days FROM Users WHERE ID = @RecordID";

                using (SqlCommand selectCommand = new SqlCommand(selectQuery, connection))
                {
                    selectCommand.Parameters.AddWithValue("@RecordID", recordIDToUpdate);

                    // 執行 SQL 查詢
                    object result = selectCommand.ExecuteScalar();

                    if (result != null)
                    {
                        logindays = Convert.ToInt32(result);
                    }
                }
            }
        }
        
        int collect_animals;
        private void search_collection()//查詢動物蒐集個數
        {
            // 替換為您的連線字串
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;" +
                 "AttachDbFilename= |DataDirectory|newuserdata.mdf;" +
                "Integrated Security=True";

            // 替換為實際的資料值
            string recordIDToUpdate = "user01";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string selectQuery = "SELECT collect_animal FROM Users WHERE ID = @RecordID";

                using (SqlCommand selectCommand = new SqlCommand(selectQuery, connection))
                {
                    selectCommand.Parameters.AddWithValue("@RecordID", recordIDToUpdate);

                    // 執行 SQL 查詢
                    object result = selectCommand.ExecuteScalar();

                    if (result != null)
                    {
                        collect_animals = Convert.ToInt32(result);
                    }
                }
            }
        }
        private void update_animalcollect(int newValue1)//更新animal_collection數
        {
            // 替換為您的連線字串
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;" +
                 "AttachDbFilename= |DataDirectory|newuserdata.mdf;" +
                "Integrated Security=True";

            // 替換為實際的 SQL 更新語句
            string updateQuery = "UPDATE Users SET collect_animal = @NewValue1 WHERE ID = @RecordID";

            // 替換為實際的資料值
            string recordIDToUpdate = "user01";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand(updateQuery, connection))
                {
                    // 使用參數化查詢以避免 SQL 注入

                    command.Parameters.AddWithValue("@NewValue1", newValue1);
                    command.Parameters.AddWithValue("@RecordID", recordIDToUpdate);

                    // 執行 SQL 更新語句
                    int rowsAffected = command.ExecuteNonQuery();

                    Console.WriteLine($"{rowsAffected} 行資料已更新");
                }

            }
        }
        private void update_collection_accurate(string name,int newValue1)//更新明確動物種類
        {
            // 替換為您的連線字串
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;" +
                 "AttachDbFilename= |DataDirectory|newuserdata.mdf;" +
                "Integrated Security=True";
            // 替換為實際的 SQL 更新語句
            string updateQuery = $"UPDATE Users SET {name} = @NewValue1 WHERE ID = @RecordID";
            // 替換為實際的資料值
            string recordIDToUpdate = "user01";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand(updateQuery, connection))
                {
                    // 使用參數化查詢以避免 SQL 注入

                    command.Parameters.AddWithValue("@NewValue1", newValue1);
                    command.Parameters.AddWithValue("@RecordID", recordIDToUpdate);

                    // 執行 SQL 更新語句
                    int rowsAffected = command.ExecuteNonQuery();

                    Console.WriteLine($"{rowsAffected} 行資料已更新");
                }
               
            }
        }
        private void update_login(int newValue1)//更新login天數
        {
            // 替換為您的連線字串
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;" +
                 "AttachDbFilename= |DataDirectory|newuserdata.mdf;" +
                "Integrated Security=True";

            // 替換為實際的 SQL 更新語句
            string updateQuery = "UPDATE Users SET login_days = @NewValue1 WHERE ID = @RecordID";

            // 替換為實際的資料值
            string recordIDToUpdate = "user01";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand(updateQuery, connection))
                {
                    // 使用參數化查詢以避免 SQL 注入
                    command.Parameters.AddWithValue("@NewValue1", newValue1);
                    command.Parameters.AddWithValue("@RecordID", recordIDToUpdate);
                    // 執行 SQL 更新語句
                    int rowsAffected = command.ExecuteNonQuery();
                }
            }
        }
        int feed_value;
        private void update(int newValue1)//更新feed數
        {
            // 替換為您的連線字串
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;" +
                 "AttachDbFilename= |DataDirectory|newuserdata.mdf;" +
                "Integrated Security=True";
            // 替換為實際的 SQL 更新語句
            string updateQuery = "UPDATE Users SET feed_times = @NewValue1 WHERE ID = @RecordID";
            // 替換為實際的資料值
            string recordIDToUpdate = "user01";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand(updateQuery, connection))
                {
                    // 使用參數化查詢以避免 SQL 注入

                    command.Parameters.AddWithValue("@NewValue1", newValue1);
                    command.Parameters.AddWithValue("@RecordID", recordIDToUpdate);

                    // 執行 SQL 更新語句
                    int rowsAffected = command.ExecuteNonQuery();

                    Console.WriteLine($"{rowsAffected} 行資料已更新");
                }
                string selectQuery = "SELECT feed_times FROM Users WHERE ID = @RecordID";

                using (SqlCommand selectCommand = new SqlCommand(selectQuery, connection))
                {
                    selectCommand.Parameters.AddWithValue("@RecordID", recordIDToUpdate);

                    // 執行 SQL 查詢
                    object result = selectCommand.ExecuteScalar();

                    if (result != null)
                    {
                        // 更新 label1.Text 的值
                        label1.Text = result.ToString();
                        feed_value = Convert.ToInt32(result);
                    }
                }
            }
        }
        //開始運行主要遊戲功能
        DataSet ds; SqlDataAdapter daEmp;
        System.Media.SoundPlayer sp = new SoundPlayer();
        private void Form4_Load(object sender, EventArgs e)
        {
            bg.BackColor = Color.Transparent;
            groupBox1.Parent = bg;
            label4.Parent = bg;label3.Parent = bg;
            animal.Parent = bg;
            search_currentanimal();
            search_login();
            search_collection();
            string cn = @"Data Source=(LocalDB)\MSSQLLocalDB;" +
                     "AttachDbFilename= |DataDirectory|newuserdata.mdf;" +
                        "Integrated Security=True";
            ds = new DataSet();
            daEmp = new SqlDataAdapter("SELECT * FROM Users", cn);
            daEmp.Fill(ds, "Users");
            label1.DataBindings.Add("Text", ds, "Users.feed_times");
          
            label2.BackColor = Color.Transparent;
            progressBar1.Minimum = 0;
            progressBar1.Maximum = 20;
            progressBar1.Step = 1;

            sp.SoundLocation = @"bg.wav";
            sp.PlayLooping();
        }
        private void Form4_FormClosing(object sender, EventArgs e) { sp.Stop(); }
        int Today_D, Today_M, Today_Y;int animal_sucess = 0;
       
        private void button1_Click(object sender, EventArgs e)
        {
            DateTime today = DateTime.Now;
            Today_D = int.Parse(today.ToString("dd"));
            Today_M = int.Parse(today.ToString("MM"));
            //判斷是否有動物
            if (button1.ImageIndex >= 0)
            {
                animal.Visible = true;
                if (recievefeed == 0)
                {
                    MessageBox.Show("沒有飼料了喔!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    recievefeed--;
                    update(recievefeed);
                    //餵食進度
                    count1 = logindays - feed_value;
                    progressBar1.Value = count1;

                    if (progressBar1.Value >= 1)//判斷動物是否養成成功
                    {
                        if (Today_D <= 30 || Today_D <= 31)
                        {
                            animal_sucess += 1;
                            playeraccount accountInstance = playeraccount.GetInstance();
                            // 在這裡使用 account 實例
                            accountInstance.ValueToPass = animal_sucess;
                            // 在這裡使用 form5 實例//讓form5接收值
                            //Form5 form5Instance = Form5.GetInstance();
                            //form5Instance.ValueToPass_feed = recievefeed;
                            MessageBox.Show("養成成功!\n快去動物圖鑑再選擇一隻來養吧~", "成功蒐集1隻", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            //更新蒐集的動物數
                            collect_animals++;
                            update_animalcollect(collect_animals);
                            //更新蒐集的動物種類
                            search_currentanimal();
                            update_collection_accurate(animalresult,1);
                            //Form6 tryy = new Form6();
                            //tryy.Show();
                            //動物消失 animal.Visible = false;
                            //登入天數和餵養次數通通歸0
                            recievefeed = 0;
                            update(recievefeed);
                            logindays = 0;
                            update_login(logindays);
                            count1 = logindays - feed_value;
                            progressBar1.Value = count1;

                        }
                    }
                    else
                    {
                        if (Today_D == 30 || Today_D == 31) 
                        {
                            //登入天數和餵養次數通通歸0
                            recievefeed = 0;
                            update(recievefeed);
                            logindays = 0;
                            update_login(logindays);
                            count1 = logindays - feed_value;
                            progressBar1.Value = count1;
                            MessageBox.Show("養成失敗!\n再接再厲!快去動物圖鑑再重新養一隻吧~", "失敗", MessageBoxButtons.OK, MessageBoxIcon.Error); 
                        }
                    
                    }
                }
            }
            //else { MessageBox.Show("目前沒有養動物喔!\n", "提示", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); }
        }
        
        int move1, move2;
        // Create an array of image paths or Image objects
        private Image[] images = { Properties.Resources.deer1, Properties.Resources.fox1, Properties.Resources.cat1, Properties.Resources.羊駝, Properties.Resources.矮袋鼠, Properties.Resources.tiger, Properties.Resources.刺蝟1, Properties.Resources.panda1, Properties.Resources.elephant, Properties.Resources.松鼠1, Properties.Resources.熊2, Properties.Resources.圖片12 };

        private void button2_MouseMove(object sender, MouseEventArgs e)
        {
            this.label4.Visible = true;
            this.label4.Location = new Point(80, 123);
            this.label4.Text ="動物圖鑑 or 選擇動物";
           
        }

        private void button2_MouseLeave(object sender, EventArgs e)
        {
            this.label4.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form form = new Form5();//換動物養
            form.Show();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Random rd1 = new Random();
            move1 = rd1.Next(-100, 100);
            Random rd2 = new Random();
            move2 = rd2.Next(-15, 15);
            // button1.ImageIndex = ValueToPass_picindex;
            if (ValueToPass_picindex != 0) { button1.ImageIndex = ValueToPass_picindex; } else { button1.ImageIndex = animalindex_category[animalresult]; }

            if (animal.Location.X <= 615 && animal.Location.X >= -3 && animal.Location.Y >= 102 && animal.Location.Y <= 269)
            {
                animal.Left = move1 + animal.Location.X;
                animal.Top = move2 + animal.Location.Y;

                animal.Image = images[button1.ImageIndex];
            }
            else
            {
                animal.Image = images[button1.ImageIndex];
                animal.Left = 302;
                animal.Top = 225;
            }
        }
        
    }
}
