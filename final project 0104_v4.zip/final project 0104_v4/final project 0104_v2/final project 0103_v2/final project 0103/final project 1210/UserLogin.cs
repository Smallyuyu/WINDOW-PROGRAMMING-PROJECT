﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace final_project_1210
{
    public partial class UserLogin : Form
    {
        public UserLogin()
        {
            InitializeComponent();
        }

        private void UserLogin_Load(object sender, EventArgs e)
        {

        }
        //目前使用者
        public void current_user(string recordIDToUpdate)
        {
            // 替換為您的連線字串
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;" +
                 "AttachDbFilename= |DataDirectory|newuserdata.mdf;" +
                "Integrated Security=True";
            // 替換為實際的 SQL 更新語句
            string updateQuery = $"UPDATE 目前使用者 SET Id = @NewValue1";
            // 替換為實際的資料值

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand(updateQuery, connection))
                {

                    command.Parameters.AddWithValue("@NewValue1", recordIDToUpdate);
                    // 執行 SQL 更新語句
                    int rowsAffected = command.ExecuteNonQuery();
                }

            }
        }
        //登入
        private void button1_Click(object sender, EventArgs e)
        {
            string account = textBox1.Text;
            string password = textBox2.Text;
            if(check_valid(account) && check_valid(password))
            {
                if (Form1.login_sys(account,password) == 0)
                {
                    Form1.account = account;
                    Form1.password = password;
                    Form1.login = true;
                    MessageBox.Show("登入成功!");
                    //更新目前使用者table的值
                    current_user(account);
                    Form1.CreateNewTable(account);
                    this.Close();
             
                }
                else if(Form1.login_sys(account, password) == 1)
                {
                    MessageBox.Show("密碼錯誤!", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    MessageBox.Show("帳號不存在!", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("含有異常字元!", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        //離開
        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do you really want to exit?", "Dialog Title", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }
        public static string valid_ch = "~`!@#$%^&*()_-+={[}]|\\:;\"'<,>.?/ ";
        public static bool check_valid(string s)
        {
            if(s == null || s == string.Empty)
            {
                return false;
            }
            for(int i =  0; i < valid_ch.Count(); i++)
            {
                if (s.Contains(valid_ch[i]))
                {
                    return false;
                }
            }
            return true;
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Visible = false;
            CreateAccount ca = new CreateAccount();
            ca.ShowDialog();
            Visible = true;
        }
    }
}
