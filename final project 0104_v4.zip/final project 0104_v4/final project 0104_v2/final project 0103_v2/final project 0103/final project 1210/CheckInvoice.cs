﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace final_project_1210
{
    public partial class CheckInvoice : Form
    {
        public CheckInvoice()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string head = Form1.winning_number[0];
            string head2 = Form1.winning_number[1];
            List<string> sh = Form1.winning_number.GetRange(2,3);
            if (textBox1 == null) return;
            if(textBox1.Text == String.Empty) return;
            if(textBox1.Text.Length != 8) return;
            int cnt = 0;
            if(textBox1.Text == head)
            {
                label4.Text = "特別獎！";
                label4.BackColor = Color.Red;
                return;
            }
            if(textBox1.Text == head2)
            {
                label4.Text = "特獎！";
                label4.BackColor = Color.Red;
                return;
            }
            foreach (var x in sh)
            {
                cnt = 0;
                for (int i = 7; i >= 0; i--)
                {
                    if (textBox1.Text[i] == x[i])
                    {
                        cnt++;
                    }
                    else
                    {
                        break;
                    }
                }
                if (cnt < 3)
                {
                    label4.Text = "沒中";
                    label4.BackColor = Color.Empty;
                }
                else if(cnt == 3)
                {
                    label4.Text = "六獎！";
                    label4.BackColor = Color.Red;
                }
                else if (cnt == 4)
                {
                    label4.Text = "五獎！";
                    label4.BackColor = Color.Red;
                }
                else if (cnt == 5)
                {
                    label4.Text = "四獎！";
                    label4.BackColor = Color.Red;
                }
                else if (cnt == 6)
                {
                    label4.Text = "三獎！";
                    label4.BackColor = Color.Red;
                }
                else if (cnt == 7)
                {
                    label4.Text = "二獎！";
                    label4.BackColor = Color.Red;
                }
                else
                {
                    label4.Text = "頭獎！";
                    label4.BackColor = Color.Red;
                }
                if (cnt >= 3) return;
            }
        }
    }
}
