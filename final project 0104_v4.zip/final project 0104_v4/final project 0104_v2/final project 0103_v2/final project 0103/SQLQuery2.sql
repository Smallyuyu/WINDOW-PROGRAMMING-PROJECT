﻿INSERT INTO 目前使用者(Id)VALUES 
('user01')