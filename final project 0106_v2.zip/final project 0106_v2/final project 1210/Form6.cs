﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace final_project_1210
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            string cn = @"Data Source=(LocalDB)\MSSQLLocalDB;" +
                 "AttachDbFilename= |DataDirectory|newuserdata.mdf;" +
                "Integrated Security=True"; //設為True 指定使用Windows 帳號認證連接資料庫
            SqlConnection db = new SqlConnection(cn);
            db.Open();
            SqlDataAdapter ap = new SqlDataAdapter
                ("SELECT * FROM Users", db);
            DataSet ds = new DataSet();
            ap.Fill(ds, "Users");
            dataGridView1.DataSource = ds.Tables["Users"];
            db.Close();
        }
    }
}
