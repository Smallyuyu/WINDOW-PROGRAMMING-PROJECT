﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace final_project_1210
{
    public partial class preference : Form
    {
        public string SelectedDateFormat { get; private set; }
        public double exchangeRate = 1;
        private Form1 mainForm;
        double ex;
        public preference(Form1 mainForm)
        {
            InitializeComponent();
            this.mainForm = mainForm;
            ex =Form1.search_prefer("幣值");

        }

        public preference()
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string selectedColor = color_cbx.SelectedItem.ToString();
            if(selectedColor == "blue")
            {
                Color color = Color.LightBlue;
                mainForm.SetTabPageBackgroundColor(color);
            }
            else if (selectedColor == "red")
            {
                Color color = Color.IndianRed;
                mainForm.SetTabPageBackgroundColor(color);
            }
            else if (selectedColor == "light")
            {
                Color color = Color.White;
                mainForm.SetTabPageBackgroundColor(color);
            }
            else if (selectedColor == "dark")
            {
                Color color = Color.Gray;
                mainForm.SetTabPageBackgroundColor(color);
            }
            else if (selectedColor == "none")
            {
                Color color = Color.Transparent;
                mainForm.SetTabPageBackgroundColor(color);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (fontDialog1.ShowDialog() == DialogResult.OK)
            {   
                font.Font = fontDialog1.Font;
            }
            mainForm.ChangeAllTextFont(fontDialog1.Font);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SelectedDateFormat = comboBox1.Text.ToString();
            mainForm.ChangeDateFormat(SelectedDateFormat);
        }
        private string SelectedCurrency;
        private string current_money_type="TWD"; 
        private void button4_Click(object sender, EventArgs e)
        {
            SelectedCurrency = comboBox2.SelectedItem.ToString();       
            if (SelectedCurrency != current_money_type)
            {
                double now_rate = exchangeRate;
                if (SelectedCurrency == "USD") { exchangeRate = 0.03; }
                else if (SelectedCurrency == "JPY") { exchangeRate = 4.67; }
                else if (SelectedCurrency == "EUR") { exchangeRate = 5; }
                else if (SelectedCurrency == "KRW") { exchangeRate = 42.34; }
                else if (SelectedCurrency == "TWD") { exchangeRate = 1; }

                current_money_type = SelectedCurrency;
                mainForm.ChangeCurrency(now_rate,exchangeRate);
                Form1.current_pre("幣值",exchangeRate);

            }
        }
    }
}
